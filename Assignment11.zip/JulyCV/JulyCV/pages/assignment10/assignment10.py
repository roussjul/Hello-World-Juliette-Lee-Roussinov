from flask import Blueprint
from flask import Flask, url_for, redirect, render_template
from flask import request, session
import mysql.connector

#assignment10 blueprint definition
assignment10 = Blueprint('assignment10', __name__, static_folder='static',
                         static_url_path="/assignment10",
                         template_folder='templates')

# Routes
@assignment10.route('/assignment10', methods=['GET', 'POST'])
def assignment10_function():
    if request.method == 'POST':
        userName = request.form['UserName']
        userPassword = request.form['UserPassword']
        firstName = request.form['firstName']
        lastName = request.form['lastName']
        email = request.form['email']
        query = "INSERT INTO users(UserName, UserPassword, firstName, lastName, email) VALUES ('%s', '%s', '%s', '%s', '%s')" % (userName, userPassword, firstName, lastName, email)
        return_value = interact_db(query, 'commit')
        selectUserQuery = "SELECT * FROM users WHERE UserName='%s';" % userName
        singleUser = interact_db(selectUserQuery, 'fetch')
        allUsers = "SELECT * FROM users"
        query_result = interact_db(allUsers, 'fetch')
        return render_template('Assignment10.html', singleUser=singleUser[0], users=query_result)

    else:
        query = "SELECT * FROM users"
        query_result = interact_db(query, 'fetch')
        return render_template('Assignment10.html', users=query_result)


@assignment10.route('/assignment10/deletion', methods=['GET', 'POST'])
def assignment10Delete_function():

    if request.method == 'GET':
        userID = request.args['ID']
        query = "DELETE FROM users WHERE ID='%s';" % userID
        interact_db(query, query_type='commit')
    return redirect('/assignment10')

@assignment10.route('/assignment10/update', methods=['GET', 'POST'])
def assignment10Update_function():

    if request.method == 'POST':
        userID = request.form['ID']

        setQuery = ""

        for key in request.form:
           value = request.form[key]
           if key != 'ID' and value != '':
               setQuery += key + "='" + value + "' ,"

        setQuery = setQuery[:-1]

        query = "UPDATE users SET " + setQuery + " WHERE ID='%s';" % (userID)
        interact_db(query, query_type='commit')

    return redirect('/assignment10')


def interact_db(query, query_type: str):
    return_value = False
    connection = mysql.connector.connect(host='localhost', user='root', passwd='root', database='assignment10')
    cursor = connection.cursor(named_tuple=True)
    cursor.execute(query)

    if query_type == 'commit':
        #Used for insert, update or delete statements.
        #Returns the number of rows affected by the query (a non-negative int)
        connection.commit()
    return_value = True

    if query_type == 'fetch':
        #Use for select statement.
        #Returns: False if the query failed, or the result of the query is successful.
        query_result= cursor.fetchall()
        return_value = query_result

    connection.close()
    cursor.close()
    return return_value
