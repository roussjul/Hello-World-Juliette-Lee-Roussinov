from flask import Flask, url_for, redirect, render_template
from flask import request, session
import mysql.connector

app = Flask(__name__)
app.secret_key = '3333'

from pages.CVJulietteLeeRoussinov.CVJulietteLeeRoussinov import CVJulietteLeeRoussinov
app.register_blueprint(CVJulietteLeeRoussinov)

from pages.assignment10.assignment10 import assignment10
app.register_blueprint(assignment10)

@app.route('/Contact')
def Contact_func():
    return render_template('ContactMe.html', username=session.get('User_Name'))


@app.route('/Assignment8')
def Assignment8_func():
    userInfo = {'firstName' : 'John', 'lastName' : 'Pattrucci', 'age' : '32', 'gender' : 'male'}

    return render_template('Assignment8.html', user=userInfo, hobbies=['Reading', 'Sports', 'Painting'], musicStyles=('Pop','Rock','Soul'), username=session.get('User_Name'))


@app.route('/Assignment8/2')
def page2_func():
    userInfo = {'firstName': 'John', 'lastName': 'Pattrucci', 'age': '32', 'gender': 'male'}

    return render_template('page2.html', user=userInfo, hobbies=['Reading', 'Sports', 'Painting'],
                           musicStyles=('Pop', 'Rock', 'Soul'),username=session.get('User_Name'))

#This is the start of assignment 9
@app.route('/log-out', methods=['GET'])
def LogOut_function():
        session['User_Name'] = None

        return render_template('assignment9.html', request_method=request.method)

@app.route('/assignment9', methods=['GET', 'POST'])
def Assignment9_function():
        users = [
            {'User_Name': 'Loci666', 'Password': '44442222', 'Email': 'badLucky@gmail.com'},
            {'User_Name': 'Thor321', 'Password': '123123', 'Email': 'thorsy@gmail.com'},
            {'User_Name': 'catWoman90', 'Password': '76432', 'Email': 'catGirl@gmail.com'}
        ]
        SecondaryUsers = []
        if request.method == 'POST':
            password = request.form['password']
            session['User_Name'] = request.form['usernameRegistration']
        else:
            searchMail = request.args.get('email')

            if searchMail == '':
                SecondaryUsers = users
            else:
                for user in users:
                    if user['Email'] == searchMail:
                        SecondaryUsers.append(user)

        return render_template('assignment9.html', request_method=request.method, username=session.get('User_Name'),
                               users=SecondaryUsers)

#Assignment 11

@app.route('/assignment11/users')
def getUsers_func():
    query="SELECT * FROM users"
    query_result = interact_db(query, 'fetch')
    jsonFormat = list(map(lambda row:row._asdict(), query_result))
    return render_template('assignment11.html', jsonFormat=jsonFormat)

@app.route('/assignment11/users/selected', defaults={'ID':6})
@app.route('/assignment11/users/selected/<int:ID>')
def getUser_func(ID = None):
    if ID:
        query = "SELECT * FROM users WHERE ID=%s LIMIT 1" % ID
        query_result = interact_db(query, 'fetch')
        if query_result:
            jsonFormat = list(map(lambda row: row._asdict(), query_result))
            return render_template('assignment11.html', jsonFormat=jsonFormat[0])
        else:
            return 'This user does not exists in the system'


def interact_db(query, query_type: str):
    return_value = False
    connection = mysql.connector.connect(host='localhost', user='root', passwd='root', database='assignment10')
    cursor = connection.cursor(named_tuple=True)
    cursor.execute(query)

    if query_type == 'commit':
        #Used for insert, update or delete statements.
        #Returns the number of rows affected by the query (a non-negative int)
        connection.commit()
    return_value = True

    if query_type == 'fetch':
        #Use for select statement.
        #Returns: False if the query failed, or the result of the query is successful.
        query_result= cursor.fetchall()
        return_value = query_result

    connection.close()
    cursor.close()
    return return_value


if __name__ == '__main__':
    app.run(debug=True)
