from flask import Flask, url_for, redirect, render_template

app = Flask(__name__)


@app.route('/')
def Homepage_func():
    return render_template('CVJulietteLeeRoussinov.html')


@app.route('/Contact')
def Contact_func():
    return render_template('ContactMe.html')


@app.route('/Assignment8')
def Assignment8_func():
    userInfo = {'firstName' : 'John', 'lastName' : 'Pattrucci', 'age' : '32', 'gender' : 'male'}

    return render_template('Assignment8.html', user=userInfo, hobbies=['Reading', 'Sports', 'Painting'], musicStyles=('Pop','Rock','Soul'))


@app.route('/Assignment8/2')
def page2_func():
    userInfo = {'firstName': 'John', 'lastName': 'Pattrucci', 'age': '32', 'gender': 'male'}

    return render_template('page2.html', user=userInfo, hobbies=['Reading', 'Sports', 'Painting'],
                           musicStyles=('Pop', 'Rock', 'Soul'))




if __name__ == '__main__':
    app.run(debug=True)
