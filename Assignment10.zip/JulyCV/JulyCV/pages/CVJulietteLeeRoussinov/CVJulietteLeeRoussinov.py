from flask import Blueprint
from flask import Flask, url_for, redirect, render_template
from flask import request, session
import mysql.connector

#CV blueprint definition
CVJulietteLeeRoussinov = Blueprint('CVJulietteLeeRoussinov', __name__, static_folder='static',
                         static_url_path="/",
                         template_folder='templates')

@CVJulietteLeeRoussinov.route('/')
def Homepage_func():
    return render_template('CVJulietteLeeRoussinov.html', username=session.get('User_Name'))