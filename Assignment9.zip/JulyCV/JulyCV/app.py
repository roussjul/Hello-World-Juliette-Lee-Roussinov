from flask import Flask, url_for, redirect, render_template
from flask import request, session

app = Flask(__name__)
app.secret_key = '3333'


@app.route('/')
def Homepage_func():
    return render_template('CVJulietteLeeRoussinov.html', username=session.get('User_Name'))


@app.route('/Contact')
def Contact_func():
    return render_template('ContactMe.html', username=session.get('User_Name'))


@app.route('/Assignment8')
def Assignment8_func():
    userInfo = {'firstName' : 'John', 'lastName' : 'Pattrucci', 'age' : '32', 'gender' : 'male'}

    return render_template('Assignment8.html', user=userInfo, hobbies=['Reading', 'Sports', 'Painting'], musicStyles=('Pop','Rock','Soul'), username=session.get('User_Name'))


@app.route('/Assignment8/2')
def page2_func():
    userInfo = {'firstName': 'John', 'lastName': 'Pattrucci', 'age': '32', 'gender': 'male'}

    return render_template('page2.html', user=userInfo, hobbies=['Reading', 'Sports', 'Painting'],
                           musicStyles=('Pop', 'Rock', 'Soul'),username=session.get('User_Name'))

#This is the start of assignment 9
@app.route('/log-out', methods=['GET'])
def LogOut_function():
        session['User_Name'] = None

        return render_template('assignment9.html', request_method=request.method)

@app.route('/assignment9', methods=['GET', 'POST'])
def Assignment9_function():
        users = [
            {'User_Name': 'Loci666', 'Password': '44442222', 'Email': 'badLucky@gmail.com'},
            {'User_Name': 'Thor321', 'Password': '123123', 'Email': 'thorsy@gmail.com'},
            {'User_Name': 'catWoman90', 'Password': '76432', 'Email': 'catGirl@gmail.com'}
        ]
        SecondaryUsers = []
        if request.method == 'POST':
            password = request.form['password']
            session['User_Name'] = request.form['usernameRegistration']
        else:
            searchMail = request.args.get('email')

            if searchMail == '':
                SecondaryUsers = users
            else:
                for user in users:
                    if user['Email'] == searchMail:
                        SecondaryUsers.append(user)

        return render_template('assignment9.html', request_method=request.method, username=session.get('User_Name'),
                               users=SecondaryUsers)


if __name__ == '__main__':
    app.run(debug=True)
